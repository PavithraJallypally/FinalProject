package com.app.Registration_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
